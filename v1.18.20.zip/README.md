This is a set of demo files for the [KRTPluginA](https://github.com/jackokring/KRTPluginA) VCV Rack plugin repository. It might also include builds for linux of the plugin (**-lin.zip**).

Files not allowed in the main repository because of build pipeline requirements might be here too, such as pictures. There is also a discussions link on this page.

If will try to archive the repository to a **.zip** file if the files might not match the publically available [Plugin Build](https://library.vcvrack.com/KRTPluginA) as I save new test patches or changes. Hopefully, this means that people having only the public build from the official library may still open the files in the provided **.zip** files by version number.