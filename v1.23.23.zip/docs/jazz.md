# Jazz Standard
A simple 0V upto 10V standard ramp up covering 64 beats. This is 1V per 6.4 beats. It allows control of pattern offset via CV. 

Well, I likely mean 6.4 quarter notes, you know, the thing a drum machine has 16 of. I wonder if drummers make good cardiac patients?